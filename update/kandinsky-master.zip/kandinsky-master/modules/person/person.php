<?php
get_template_part('/modules/person/widgets');
get_template_part('/modules/person/hooks');
// get_template_part('/modules/person/tax');
get_template_part('/modules/person/templates');

class KND_Person {
    
    
}
