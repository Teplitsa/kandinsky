# Kandinsky changelog
All notable changes to this project will be documented in this file.

## [Unreleased]

## [1.3.0] - 2018-08-07
### Added
- Child theme support added.

### Fixed
- Timeout error fixed. Template installation devided into separate AJAX steps.

## [1.2.0] - 2017-10-30
### Added
- Version on dashboard and in console menus.

### Fixed
- Important security issues.

## [1.1.0] - 2017-10-17
### Added
- Ability to update theme right from admin panel.

### Fixed
- Invisible text in header.
- Other minor reported issues.

## [1.0.0] - 2017-09-27
### First official release!

[Unreleased]: https://github.com/Teplitsa/kandinsky/compare/v1.3.0...HEAD
[1.3.0]: https://github.com/Teplitsa/kandinsky/compare/v1.2.0...v1.3.0
[1.2.0]: https://github.com/Teplitsa/kandinsky/compare/v1.1.0...v1.2.0
[1.1.0]: https://github.com/Teplitsa/kandinsky/compare/v1.0.0...v1.1.0
